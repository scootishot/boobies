Bing Chilling.

MTL find the textures via directories, example:
C:/Program Files (x86)/Steam/steamapps/common/Crab Game/TestMaps/Playground3/textures/Texture.PNG

